tanjirokamado crack fb

pkg update && pkg upgrade

--> pkg install python3

--> pkg install requests

--> pip2 install mechanize

--> git clone https://github.com/tanjiro/cr4ck

--> cd tanjiro

--> git pull

--> python2 tanjiro.py
